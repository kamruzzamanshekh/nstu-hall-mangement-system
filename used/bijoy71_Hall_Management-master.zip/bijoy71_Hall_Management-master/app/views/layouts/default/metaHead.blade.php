<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="keyword" content="">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>Login Page</title>

    <!-- Bootstrap core CSS -->
    {{HTML::style('assets/css/bootstrap.min.css')}}
    {{HTML::style('assets/css/bootstrap-reset.css')}}
    {{HTML::style('font-awesome/css/font-awesome.css')}}
    {{HTML::style('assets/css/style.css?1')}}
    {{HTML::style('assets/css/style-responsive.css')}}

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
</head>