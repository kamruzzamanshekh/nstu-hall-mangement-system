<aside>
    <div id="sidebar" class="nav-collapse">
       <!-- sidebar menu start-->            
        <div class="leftside-navigation">
            <ul class="sidebar-menu" id="nav-accordion">
            <li>
                <a href="#">
                    <i class="fa fa-dashboard"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="sub-menu">
                <a href="javascript:;">
                    <i class="fa fa-user"></i>
                    <span>Student Management</span>
                </a>
                <ul class="sub">
                    <li><a href="#">Create New Student</a></li>
                    <li><a href="#">Show Student List</a></li>
                </ul>
            </li>
            <li class="sub-menu">
                <a href="#">
                    <i class="fa fa-th"></i>
                    <span>User Info</span>
                </a>
                <ul class="sub">
                    <li><a href="#">Create New User</a></li>
                    <li><a href="#">Show User List</a></li>
                </ul>
            </li>
            </ul>
        </div>        
<!-- sidebar menu end-->
    </div>
</aside>
<!--sidebar end-->