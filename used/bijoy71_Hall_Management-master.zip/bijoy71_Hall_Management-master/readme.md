

<b>bijoy71 is officially used by Bijoy 71 hall of University of Dhaka under the supervision of provost sir Asif Hossain Khan.<b>

This project is developed using <b>Laravel framework<b>

MySQL is used as the DBMS(the database file attached in this project is currently empty)

For demo login use the following identity:

username : nazmul

password : nazmul

(N.B. laravel vendor is not included. Install it manually.)

