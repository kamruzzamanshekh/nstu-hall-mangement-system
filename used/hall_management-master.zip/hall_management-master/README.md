# hall_management
This is a management system for university hall, where student can apply for the seat and do further processing.
