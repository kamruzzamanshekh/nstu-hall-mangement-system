<footer class="footer" style="position:fixed;width:auto;right:0;left:0;margin-top:30px">
	<div class="container footer-bottom" style="margin-left:100px">
		<div style="margin-left: 100px">
			<p style="padding-left: 50px; padding-top:20px; text-align: center;">Copyright © IIT NSTU 2021 | Designed and Developed by <b> <!--<a class="link" href="<?php //echo $basedir; ?>aboutUs.php">TF_sQuare.</a> -->TF_sQuare.</b></p>
		</div>
	</div>
</footer>
