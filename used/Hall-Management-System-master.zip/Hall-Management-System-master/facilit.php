<?php


ob_start();
     session_start();
include "home.php";
include "function.php";
?>
 
 <div class=" container well"  style="margin-top:-20px">
<div class="row">
<div class="span4"></div>
<div class="span5">
<p>
  <h3 style="margin-left:60px;">About Fazlul Haque hall</h3><i>   KHULNA UNIVERSITY OF ENGINEERING & TECHNOLOGY is one of the most leading 
Highter educational Institute of Bangladesh,established in 1967.It has Six Magnificant
Residential Halls.Of them Fazlul Haque hall is the most oldest and it is said that 
number one hall of kuet.It is named after the great leader of our country Sher-e-Bangla AK Fazlul haque,one of the greatest 
politician of our country who changed the revolution in agriculture,economics and almost all sectors in our national catagories
So due respect towards his great contribution,this halls journey started.Since the very beginning of its foundation,its aimed
to flourish the path of fullfill the students aim and creats better environment for studies.So far,it is successful.Now it is
said that best engineers of this country are from kuet of this fazlul haque hall.

There are almost 260 studenst staying in this hall.The inner environment of the hall is really very excellent
.The all three storeyed building in this hall   is blessed with greeny trees.Its libraray
, common room and TV room facilities keeps satisfaction than another hall of kuet.</i>
</p>
</div>
<div class="span3 height="1000px"></div>
<br><br>
         &nbsp; &nbsp; &nbsp;<img class="img img-circle" src="images/kuetloc.png"></img>
		 <br><br>
		 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; kuet location in googlemap
</div>
</div>
<div class="container well" style="margin-top:-20px">	 
  <?php
  include "foother.php";
  ?>
  </div>