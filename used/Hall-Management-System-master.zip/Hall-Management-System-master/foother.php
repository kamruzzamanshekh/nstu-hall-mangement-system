<!DOCTYPE html>
<html lang="en">
<head>
  <title>foother.php</title>
  
  <meta charset="utf-8">
  
  
  

   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
  
   
   <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
   <script src="script.js"></script>
  
  
  
  <meta name="viewport" content="width=device-width:70%, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap-responsive.css">
	 <link rel="stylesheet" href="d-down.css">
  <script src="ajax/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>

</head>




  <div class="container" style="background-color:#818181">
  <div class="row-fluid" >
  <div class="span1"></div>
   <div class="span3">
   <h3>Quick Links</h3>
    <h4><a href="Khulna University of Engineering & Technology" style="color:black">kuet central library</a><h4 />
    <h4><a href="Khulna University of Engineering & Technology"style="color:black">medical center</a><h4 />
	 <h4><a href="Khulna University of Engineering & Technology"style="color:black">computer center</a><h4 />
	 <h4> <a href="#"style="color:black">Bangabandu Hall</a><h4 />
	  <h4> <a href="#"style="color:black">Lanlan Shah Hall</a><h4/>
	  </div>
   
  
  
  <div class="span2">
     <h3>ABOUT</h3>
    <h4><a href="#" style="color:black"></a><h4 />
    <h4><a href="admission.php"style="color:black">Admission</a><h4 />
	 <h4><a href="register.php"style="color:black">Registration</a><h4 />
	 <h4> <a href=" https://www.google.com.bd/maps/place/%E0%A6%AB%E0%A6%9C%E0%A6%B2%E0%A7%81%E0%A6%B2+%E0%A6%B9%E0%A6%95+%E0%A6%B9%E0%A6%B2/@22.911026,89.5210336,13.5z/data=!4m2!3m1!1s0x0:0x8329fe7d06758edf"style="color:black">Halls Map</a><h4 />
	  <h4> <a href="about.php"style="color:black">Mission and Vission</a><h4/>
	  </div>
  <div class="span2">
     <h3>Contac Us</h3>
   
   
	 <h4><a href="http://www.safiullahcse@yahoo.com"style="color:black">Yahoo</a></h4>
	 <h4> <a href="http://www.facebook.com"style="color:black">Facebook</a><h4>
	 <h4><a href="http://www.safiullahkuet@gmail.com"style="color:black">gmail</a></h4>
	
	  </div>
	  
	   <div class="span2">
     <h3>SERVICES</h3>
    <h4><a href="#" style="color:black">Facilities</a></h4>
    <h4><a href="Project.php"style="color:black">Noice Board</a></h4>
	 <h4><a href="Project.php"style="color:black">Recent news and Events</a></h4>
	 <h4> <a href="Project.php"style="color:black">Date</a><h4>
	
	  </div>
	  
  
   
   </div>
   </div>
  
   
</body>
</html>
