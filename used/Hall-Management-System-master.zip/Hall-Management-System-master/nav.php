<!DOCTYPE html>
<html>
	<head>
		<title>Md. Milon Islam</title>
		<link href="getuser.css" rel="stylesheet" type="text/css"/>
		
	</head>
	
	<body>
	
			
			<div class="fix sidebar">
					<ul>
                        <li><a style="color:#FFFFFF; background:#3b8919" href="home.html">Home</a></li>
                        <li><a href="about.html">About</a></li>
                        <li><a href="education.html">Education</a></li>
                        <li><a href="contact.html">Contact</a></li>
                        <li><a href="others.html">Others</a></li>
                        <li><a href="activepage.aspx">ASP</a></li>
					</ul>
			</div>
			
			
	</body>
</html>