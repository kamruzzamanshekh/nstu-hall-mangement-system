<?php
session_start();
include "home.php";

?>
<div class=" container well"  style="margin-top:-20px">
<div class="row">
<div class="span1"></div>
<div class="span5">
<div class="a well">
 <a href=" https://www.google.com.bd/maps/place/%E0%A6%AB%E0%A6%9C%E0%A6%B2%E0%A7%81%E0%A6%B2+%E0%A6%B9%E0%A6%95+%E0%A6%B9%E0%A6%B2/@22.911026,89.5210336,13.5z/data=!4m2!3m1!1s0x0:0x8329fe7d06758edf"> 
 <img style="margin-left:20px" class="img img-circle" src="images/kuetloc.png"></img></a>
 <br><small style="margin-left:70px">google map of fazlul haque hall</small>
  </div>
<p>
  <h4 style="margin-left:100px;">History </h4><i> KUET is one of the most significant name
  now when talk about to Engineering University of Bangladesh.It holds a prestigious position in Engineering Universities
  
   ,established in 1967.It has Six Magnificant
Residential Halls.Of them Fazlul Haque hall is the most oldest and it is said that 
number one hall of kuet.It is named after the great leader of our country Sher-e-Bangla AK Fazlul haque,one of the greatest 
politician of our country who changed the revolution in agriculture,economics and almost all sectors in our national catagories
So due respect towards his great contribution,this halls journey started.Since the very beginning of its foundation,its aimed
to flourish the path of fullfill the students aim and creats better environment for studies.So far,it is successful.Now it is
said that best engineers of this country are from kuet of this fazlul haque hall.

There are almost 260 studenst staying in this hall.The inner environment of the hall is really very excellent
.The all three storeyed building in this hall   is blessed with greeny trees.Its libraray
, common room and TV room facilities keeps satisfaction than another hall of kuet.</i>
</p>

</div>
<div class="span5">
<p>
  <h4 style="margin-left:100px;">About Fazlul Haque hall</h4><i>   KHULNA UNIVERSITY OF ENGINEERING & TECHNOLOGY is one of the most leading 
Highter educational Institute of Bangladesh,established in 1967.It has Six Magnificant
Residential Halls.Of them Fazlul Haque hall is the most oldest and it is said that 
number one hall of kuet.It is named after the great leader of our country Sher-e-Bangla AK Fazlul haque,one of the greatest 
politician of our country who changed the revolution in agriculture,economics and almost all sectors in our national catagories
So due respect towards his great contribution,this halls journey started.Since the very beginning of its foundation,its aimed
to flourish the path of fullfill the students aim and creats better environment for studies.So far,it is successful.Now it is
said that best engineers of this country are from kuet of this fazlul haque hall.

There are almost 260 studenst staying in this hall.The inner environment of the hall is really very excellent
.The all three storeyed building in this hall   is blessed with greeny trees.Its libraray
, common room and TV room facilities keeps satisfaction than another hall of kuet.</i>
</p>
</div>

</div>
</div>
 


<div class="container well" style="margin-top:-20px">	 
  <?php
  include "foother.php";
  ?>
  </div>
