<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  
  
  

   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
  
   
   <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
   <script src="script.js"></script>
  
  
  
  <meta name="viewport" content="width=device-width:70%, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap-responsive.css">
	 <link rel="stylesheet" href="d-down.css">
  <script src="ajax/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <style>
  .carousel-inner > .item > img,

  .carousel-inner > .item > a > img {
     width: 100%;
	 height:20%;
     margin: auto;
	 margin-top:0px;
	
  }
 
  </style>
</head>
<body style="bgcolor:black;margin:auto 60px 10px">


<div class="container well" style="background-color:lavender">
  <div class="container">
  <div class="row-fluid" >
   <div class="span2" style="background-color:lavender;"> <img class="img img-circle" src="images/Logo.KUET.jpg"></img>
   <br />
  <div class="row">
  <div class="span3"></div>
  <div class="span9">
   <img class="img img-round" src="images/kuetpic.png"></img>
   
   </div>
  
   </div>
   </div>
    <div class="span7" style="background-color:lavender">
	        <div class="row">
			<div class="span2"> </div>
			<div class="span10">
			<div class="row">
			 <div class="span3"></div> <div class="span9">Knowledge is power </div> </div>
			 <div class="row">
			 <div class="span2"></div>
			  <div class="span10">  <h2> Fazlul Haque Hall</h2> </div></div>
			   <div class="row">
			 <div class="span12"><h4>&nbsp;&nbsp;&nbsp;&nbsp;  Khulna University of Engineering & Technology  </h4></div>
			 </div>
			  
	           
				</div>
			</div>
       
	</div>
    <div class="span3">
	
<div class="row">
<div class="span3">

</div>

	
<div class="span9">
<p id="demo"></p></div>
</div>

<script>
var d = new Date();
document.getElementById("demo").innerHTML = d.toDateString();
</script>

	<a href="../login.php" class="btn btn-success">Login</a>
	<a href="../register.php" class="btn btn-success">Registration</a> <br /> <br />
	
<div class="row "> 
<div class="span12">
  <form>
  <input type="text"placeholder="Search..."required>
 <input type="button" value="Search">
 </form>
				
  </div>
  
	 
	 </div>
	 </div>
	
	</div>
  
  </div>
 
  
</div>
</div>
<div class="container well">
<a href="#"class="btn btn-info btn-round"><i class="icon icon-read"></i>Home</a>
<a href="../about.php"class="btn btn-info">About</a>
<a href="#"class="btn btn-info">Facilites</a>	  
<a href="#"class="btn btn-info">Others</a>	  

	   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

   
<a href="../login.php"class="btn btn-info btn-round">login</a>
<a href="../register.php"class="btn btn-info">Registration</a>
<a href="#"class="btn btn-info">Account</a>	  

  </div> 
  </body>
  </html>
  
  
  
  
  
  
  
  
  
  
  