<?php


ob_start();
     session_start();
include "home.php";
include "function.php";
?>
 
  <div class="container"  style="margin-top:-20px">
  <div class="row">
  <div class="span3">
    <div class="btn-group-vertical">
   <a href="admission.php" style="margin-bottom:2px"class="btn btn-primary">admission</a>
     <a href="provost.php" style="margin-bottom:2px"class="btn btn-primary">provost</a>
	<a href="Manager&Staff.php" style="margin-bottom:2px"class="btn btn-primary">Manager&Staff</a>
	  <a href="Boarders.php" style="margin-bottom:2px"class="btn btn-primary">Boarders</a>
	  </div>
	  </div>
  <div class="span8 well">
     <p>Welcome to admission section of Fazlul Hall</p>
	 <p>Fazlul haque hall is one of the most oldest hall in <a href="Khulna university of Engineering & Technology">
	 Khulna university of Engineering & Technology</a>
	 That it is said that Fazlul haque hall is the attachement of kuet excellency.So be want to be boarder of this hall some 
	 rules and regulation should be followed mandotary.Here this goes <br>
	 <b>1.</b> First of all,the boarders will have to be selected from the administrator of kuet for this hall.All the admission going 
	 students of kuet is plotted a hall seat with corresponding hall name</p>
	 <b>2.</b>
	 
	  The goes above is the first condition to become a boarder.But if a another halls 
	 boarder want to become a boarder of this hall,then he should be followed some
	 criteria.<br>
	 &nbsp;&nbsp;&nbsp;
	 <b>a.</b>
	   he has to fullfill all the payment of hall that he was attached previously.<br>
	  &nbsp;&nbsp;&nbsp; <b>b.</b>
	   Secondly he has to pay this hall admission fee advance<br>
	   
	   <b>3.</b>
	   Another thing that should be stated that halls authority has full ability for halls seat allotment.In this case,
	   cgpa and seniority is the most considerable matter<br>
	   <b>4.</b>If the boarders do any of the works that hampers educational environment ,then hall authority keep
	   ability to take action against him <br></div>
	   
	   
   
   
	  </div>
	  </div>
	  </div>
	  
 <div class="container well"  style="margin-top:-20px">	 
  <?php
  include "foother.php";
  ?>
  </div>