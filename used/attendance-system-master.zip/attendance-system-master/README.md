# Attendance System

A web based responsive attendance system.
