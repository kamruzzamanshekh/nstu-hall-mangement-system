<footer class="footer">
	<div class="container footer-bottom">
		<p>Copyright © IIT NSTU 2020 | Designed and Developed by <b><a class="link" href="<?php echo $basedir; ?>aboutUs.php">IIT 1st batch</a></b></p>
	</div>
</footer>
