<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link rel="icon" href="<?php echo $basedir; ?>nstu.png" type="image/png">

<!-- Bootstrap core CSS -->
<link rel="stylesheet" href="<?php echo $basedir; ?>vendor/bootstrap/css/bootstrap.min.css">

<!-- Custom CSS -->
<link rel="stylesheet" href="<?php echo $basedir; ?>css/style.css">

<!-- Bootstrap core javascript -->
<script src="<?php echo $basedir; ?>vendor/jquery/jquery.min.js"></script>
<script src="<?php echo $basedir; ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Plugin JavaScript -->
<script src="<?php echo $basedir; ?>vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom JavaScript for this theme -->
<script src="<?php echo $basedir; ?>js/customJS.js"></script>
