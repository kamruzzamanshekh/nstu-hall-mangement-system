<?php
include('checkteacher.php');
include('../variables.php');
 ?>

<html>
<head>
  <title>Teacher</title>
  <?php include('../headData.php'); ?>
  <script src="js/customJS.js"></script>
</head>
