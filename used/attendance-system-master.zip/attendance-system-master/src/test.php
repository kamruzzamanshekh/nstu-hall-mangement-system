<?php
$temp = "NqULL";
$t = "N/Aq";

if (!strpos($temp, "NULL") || !strpos($t, "N/A")) {
  echo "FOund";
}
 ?>
