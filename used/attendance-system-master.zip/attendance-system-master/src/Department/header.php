<?php
// error_reporting(0);
include('checkdepartment.php');
include('../variables.php');
 ?>

<html>
<head>
  <title>Department Dashboard</title>
  <?php include('../headData.php') ?>
  <script src="js/dcustomJS.js"></script>
</head>
